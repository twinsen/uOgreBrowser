#include "PlayState.h"
#include <OgreTextureUnitState.h>

using namespace Ogre;

//#define HIDE_MY_OVER_BROWSER

#define SPIN_BROWSER

PlayState* PlayState::mPlayState;

void PlayState::enter( void )
{
   mRoot             = Root::getSingletonPtr();
   mOverlayMgr       = OverlayManager::getSingletonPtr();
   mInputDevice      = EventHandler::getSingletonPtr()->getKeyboard();
   mSceneMgr         = mRoot->getSceneManager( "ST_GENERIC" );
   mCamera           = mSceneMgr->createCamera( "PlayCamera" );

   // Create the scene node
   mCamNode = mSceneMgr->getRootSceneNode()->createChildSceneNode( "CamNode1", Vector3( -400, 200, 400 ) );

   mCamNode->yaw( Degree(-45) );

   // Create the pitch node
   Ogre::SceneNode* node = mCamNode->createChildSceneNode( "PitchNode1" );
   node->attachObject( mCamera );

   mViewport         = mRoot->getAutoCreatedWindow()->addViewport( mCamera );

   mInfoOverlay      = mOverlayMgr->getByName( "Overlay/Info" );
   mPlayOverlay      = mOverlayMgr->getByName( "Overlay/PlayState" );
   mMouseOverlay     = mOverlayMgr->getByName( "Overlay/MousePointer" );

   mInfoInstruction  = mOverlayMgr->getOverlayElement( "Info/Instruction" );
   mInfoNotification = mOverlayMgr->getOverlayElement( "Info/Notification" );
   mMousePointer     = mOverlayMgr->getOverlayElement( "MousePointer/Pointer" );

   size_t tempAttr = 0;
   Ogre::RenderWindow* renderWindow = mRoot->getAutoCreatedWindow();

   // Get window handle
#if defined OIS_WIN32_PLATFORM
   HWND windowHnd;
   renderWindow->getCustomAttribute( "HWND", &tempAttr );

   windowHnd = (HWND)tempAttr;
#elif defined OIS_LINUX_PLATFORM
   size_t windowHnd;
   renderWindow->getCustomAttribute( "GLXWINDOW", &tempAttr );

   windowHnd = tempAttr;
#endif

   // set the rotation and move speed for camera
   mRotate = 0.13;
   mMove = 250;
   mDirection = Vector3::ZERO;
   mFreeLook = false;

   // set up browsers
   mBrowserPlane[0] = new Ogre::BrowserPlane( "BrowserPlaneDemo1", "www.ogre3d.org", Ogre::Vector3::UNIT_X, 0.0, 800.0, 600.0, windowHnd );
   mBrowserPlane[1] = new Ogre::BrowserPlane( "BrowserPlaneDemo2", "www.google.com", Ogre::Vector3::UNIT_X, 0.0, 800.0, 600.0, windowHnd );

   Entity *ent;

   // 1
   ent = mSceneMgr->createEntity( "BrowserPlane1", mBrowserPlane[0]->m_PlaneName );
   mBrowserNode[0] = mSceneMgr->getRootSceneNode()->createChildSceneNode("BrowserPlane1_Node");
   mBrowserNode[0]->attachObject(ent);
   ent->setMaterialName( mBrowserPlane[0]->m_MaterialName );
   ent->setCastShadows(false);

   mBrowserNode[0]->setPosition( 0, 100, 0 );
   mBrowserNode[0]->pitch( Degree(180.0) );
//   mBrowserNode[0]->yaw( Degree(123.0) );
//   mBrowserNode[0]->roll( Degree(35.0) );

   mBrowserWithFocus = -1;

   m_BrowserMap["BrowserPlane1"] = 0;

   // 2
   ent = mSceneMgr->createEntity( "BrowserPlane2", mBrowserPlane[1]->m_PlaneName );
   mBrowserNode[1] = mSceneMgr->getRootSceneNode()->createChildSceneNode("BrowserPlane2_Node");
   mBrowserNode[1]->attachObject(ent);
   ent->setMaterialName( mBrowserPlane[1]->m_MaterialName );
   ent->setCastShadows(false);

   mBrowserNode[1]->setPosition( 0, 550, 600 );
   mBrowserNode[1]->pitch( Degree(180.0) );
   mBrowserNode[1]->yaw( Degree(75.0) );
   mBrowserNode[1]->roll( Degree(135.0) );

   m_BrowserMap["BrowserPlane2"] = 1;

#if 1
   // add the ninja
   ent = mSceneMgr->createEntity( "Ninja", "ninja.mesh" );
   node = mSceneMgr->getRootSceneNode()->createChildSceneNode( "NinjaNode" );
   node->attachObject( ent );

   // create the light
   Light *light = mSceneMgr->createLight( "Light1" );
   light->setType( Light::LT_POINT );
   light->setPosition( Vector3(250, 150, 250) );
   light->setDiffuseColour( ColourValue::White );
   light->setSpecularColour( ColourValue::White );
#endif

   mSceneMgr->setAmbientLight( ColourValue( 1.0, 1.0, 1.0 ) );

   mInfoOverlay->show();
//   mPlayOverlay->show();
   mMouseOverlay->show();
}

void PlayState::exit( void )
{
   mInfoOverlay->hide();
   mPlayOverlay->hide();
   mMouseOverlay->hide();

   mSceneMgr->clearScene();
   mSceneMgr->destroyAllCameras();
   mRoot->getAutoCreatedWindow()->removeAllViewports();
}

void PlayState::pause( void )
{
   mInfoOverlay->hide();
   mPlayOverlay->hide();
   mMouseOverlay->hide();
}

void PlayState::resume( void )
{
   mInfoOverlay->show();
   mPlayOverlay->show();
   mMouseOverlay->show();

   mInfoInstruction->setCaption( "Press space for pause" );
}

void PlayState::update( unsigned long lTimeElapsed )
{
   // Update wat je moet updaten
   // really a hack...this should be done on an event not polled
   for ( int index = 0; index < (int)m_BrowserMap.size(); ++index )
   {
      mBrowserPlane[index]->UpdateMaterial();
   }

   mCamNode->translate( mCamNode->getOrientation() * mDirection * (Real)(lTimeElapsed/1000.0) );

#ifdef SPIN_BROWSER
   static Ogre::Real rotateBrowser[2] = {0.0,0.0};

   for ( int index = 0; index < (int)m_BrowserMap.size(); ++index )
   {
      if ( mBrowserWithFocus != index )
      {
         Ogre::Real rotateThisFrame = 0.005 * (Ogre::Real)lTimeElapsed/1000.0;

         rotateBrowser[index] += rotateThisFrame;

         mBrowserNode[index]->yaw( Degree( rotateBrowser[index] ) );
      }
   }
#endif   
}

void PlayState::keyPressed( const OIS::KeyEvent &e )
{
//   if ( !mBrowserHasFocus )
   {
      switch ( e.key )
      {
         case OIS::KC_UP:
         case OIS::KC_W:
            mDirection.z -= mMove;
            break;

         case OIS::KC_DOWN:
         case OIS::KC_S:
            mDirection.z += mMove;
            break;

         case OIS::KC_LEFT:
         case OIS::KC_A:
            mDirection.x -= mMove;
            break;

         case OIS::KC_RIGHT:
         case OIS::KC_D:
            mDirection.x += mMove;
            break;

         case OIS::KC_PGDOWN:
         case OIS::KC_E:
            mDirection.y -= mMove;
            break;

         case OIS::KC_PGUP:
         case OIS::KC_Q:
            mDirection.y += mMove;
            break;
      }
   }
}

void PlayState::keyReleased( const OIS::KeyEvent &e )
{
//   if ( mBrowserHasFocus )
   {
      switch ( e.key )
      {
         case OIS::KC_UP:
         case OIS::KC_W:
            mDirection.z += mMove;
            break;

         case OIS::KC_DOWN:
         case OIS::KC_S:
            mDirection.z -= mMove;
            break;

         case OIS::KC_LEFT:
         case OIS::KC_A:
            mDirection.x += mMove;
            break;

         case OIS::KC_RIGHT:
         case OIS::KC_D:
            mDirection.x -= mMove;
            break;

         case OIS::KC_PGDOWN:
         case OIS::KC_E:
            mDirection.y += mMove;
            break;

         case OIS::KC_PGUP:
         case OIS::KC_Q:
            mDirection.y -= mMove;
            break;

         case OIS::KC_SYSRQ:
         case OIS::KC_INSERT:
            {
	   	      char tmp[40];
               static unsigned int numScreenShots = 0;
		   	   sprintf( tmp, "screenshot_%d.png", ++numScreenShots );
               mRoot->getAutoCreatedWindow()->writeContentsToFile(tmp);
            }
            break;
      } // switch
   }

   if ( e.key == OIS::KC_ESCAPE )
   {
      this->requestShutdown();
   }
}

void PlayState::mouseMoved( const OIS::MouseEvent &e )
{
   if ( mFreeLook )
   {
      mCamNode->yaw( Degree(-e.state.X.rel * mRotate) );
      mCamNode->getChild( 0 )->pitch( Degree(-e.state.Y.rel * mRotate) );
   }
   else
   {
      mMousePointer->setTop( e.state.Y.abs );
      mMousePointer->setLeft( e.state.X.abs );
   }

#if 1
   int wbX;
   int wbY;
   int browserIndex;

   // check to see if the mouse is over a web browser and give it focus if it is
   if ( MouseInBrowser( e.state.X.abs, e.state.Y.abs, e.state.width, e.state.height, wbX, wbY, browserIndex ) )
   {  
      if ( mBrowserWithFocus != browserIndex )
      {
         // this seems better than sending focus on mouse down (still need to improve this)
         LLMozLib::getInstance()->focusBrowser( mBrowserPlane[browserIndex]->m_browserWindowId, true );

         mBrowserWithFocus = browserIndex;
      }
#ifdef HIDE_MY_OVER_BROWSER
      mMouseOverlay->hide();
#endif      
      LLMozLib::getInstance()->mouseMove( mBrowserPlane[browserIndex]->m_browserWindowId, wbX, wbY );
   }
   else
   {
#ifdef HIDE_MY_OVER_BROWSER
      mMouseOverlay->show();
#endif
      if ( mBrowserWithFocus == browserIndex )
      {
         LLMozLib::getInstance()->focusBrowser( mBrowserPlane[browserIndex]->m_browserWindowId, false );
      }

      mBrowserWithFocus = -1;
   }
#endif      
}

void PlayState::mousePressed( const OIS::MouseEvent &e, OIS::MouseButtonID id )
{
   switch( id )
   {
      case OIS::MB_Right:
         mFreeLook = true;
         mMouseOverlay->hide();
         break;

      case OIS::MB_Left:
         // found out if we hit the browser
         {
#if 1
            int wbX;
            int wbY;
            int browserIndex;

            if ( MouseInBrowser( e.state.X.abs, e.state.Y.abs, e.state.width, e.state.height, wbX, wbY, browserIndex ) )
            {
               mBrowserPlane[browserIndex]->MouseButtonLeftDown( wbX, wbY );
            }
#endif
         }
         break;
   }
}

void PlayState::mouseReleased( const OIS::MouseEvent &e, OIS::MouseButtonID id )
{
   switch( id )
   {
      case OIS::MB_Right:
         mFreeLook = false;
         mMouseOverlay->show();
         break;

      case OIS::MB_Left:
         // found out if we hit the browser
         {
#if 1
            int wbX;
            int wbY;
            int browserIndex;

            if ( MouseInBrowser( e.state.X.abs, e.state.Y.abs, e.state.width, e.state.height, wbX, wbY, browserIndex ) )
            {
               mBrowserPlane[browserIndex]->MouseButtonLeftUp( wbX, wbY );
            }
#endif
         }
         break;
   }
}

PlayState* PlayState::getSingletonPtr( void )
{
   if ( !mPlayState )
   {
      mPlayState = new PlayState();
   }

   return mPlayState;
}

bool PlayState::MouseInBrowser( int x, int y, int width, int height, int& outX, int& outY, int& browserIndex )
{
   bool hit = false;
   Ogre::Real wx = (Ogre::Real)width;
   Ogre::Real wy = (Ogre::Real)height;
   Ogre::Real tx = (Ogre::Real)x/wx;
   Ogre::Real ty = (Ogre::Real)y/wy;

   // calc the ray using normalised screen coordinates [0-1]
   RaySceneQuery *raySceneQuery = mSceneMgr->createRayQuery( Ray() );

   // Setup the ray scene query
   Ray mouseRay = mCamera->getCameraToViewportRay( tx, ty );
   raySceneQuery->setRay( mouseRay );
   raySceneQuery->setSortByDistance( true );

   // Execute query
   RaySceneQueryResult &result = raySceneQuery->execute();
   RaySceneQueryResult::iterator itr;

   // Get results, create a node/entity on the position
   for ( itr = result.begin(); itr != result.end(); itr++ )
   {
      if ( itr->movable && itr->movable->getName().substr(0,12) == "BrowserPlane" )
      {
         // get the entity to check
         Ogre::Entity *pentity = static_cast<Ogre::Entity*>( itr->movable );

         // was it a browser?
         TBrowserMap::iterator bItr = m_BrowserMap.find( pentity->getName() );

         if ( bItr != m_BrowserMap.end() )
         {
            hit = mBrowserPlane[bItr->second]->RayHitBrowser( pentity, mouseRay, outX, outY );

            if ( hit )
            {
               browserIndex = bItr->second;
               break;
            }
         }
      } // if
      else if ( itr->worldFragment )
      {
         break;
      } // else if
   } // for

   raySceneQuery->clearResults();

   return( hit );
}

