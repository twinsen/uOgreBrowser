#include "BrowserPlane.h"
#include <shlwapi.h>

using namespace Ogre;

String GetStartupPath();
String NumberToString( int number );
void GetMeshInformation( const Ogre::MeshPtr mesh,
                         size_t &vertex_count,
                         Ogre::Vector3* &vertices,
                         size_t &index_count,
                         unsigned long* &indices,
                         const Ogre::Vector3 &position,
                         const Ogre::Quaternion &orient,
                         const Ogre::Vector3 &scale );

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// BrowserPlane specific methods
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
BrowserPlane::BrowserPlane( const String& name, const String& startingURL, const Vector3 &rkNormal, Real fConstant, Real width, Real height, HWND hwnd )
: Ogre::MovablePlane( rkNormal, fConstant )
, m_needsUpdate(true)
, m_browserWindowId(0)
, m_Width( width )
, m_Height( height )
, m_hWnd( hwnd )
{
   std::string profileBaseDir = GetStartupPath();

   // LLMozLib startup
   LLMozLib::getInstance()->init( profileBaseDir, name );
//   m_browserWindowId = LLMozLib::getInstance()->createBrowserWindow( m_hWnd, 799 /*(int)width*/, (int)height );
   m_browserWindowId = LLMozLib::getInstance()->createBrowserWindow( m_hWnd, (int)width-1, (int)height );

   // Tell LLMozLib about the size of the browser window.
//   LLMozLib::getInstance()->setSize( m_browserWindowId, 799 /*(int)width*/, (int)height );
   LLMozLib::getInstance()->setSize( m_browserWindowId, (int)width-1, (int)height );

   // Observer events that LLMozLib emits.
   LLMozLib::getInstance()->addObserver( m_browserWindowId, this );

   // Append details to agent string.
   LLMozLib::getInstance()->setBrowserAgentId( name );

   // Go to the "home page".
   LLMozLib::getInstance()->navigateTo( m_browserWindowId, startingURL );

   CreateMaterial();

   // place the material on this plane
   MaterialPtr material = MaterialManager::getSingleton().getByName( m_MaterialName );
   material->setDepthWriteEnabled(true);

   m_PlaneName = "BrowserPlane";
   m_PlaneName += NumberToString( m_browserWindowId );

   Ogre::MeshManager::getSingleton().createPlane( m_PlaneName,
                                                  Ogre::ResourceGroupManager::DEFAULT_RESOURCE_GROUP_NAME,
                                                  *this,
                                                  m_Width,
                                                  m_Height );
}

BrowserPlane::~BrowserPlane()
{
}

void BrowserPlane::UpdateMaterial()
{
   unsigned char* pixels = GrabNewBrowserData();

   if ( pixels != NULL )
   {
      // Get the texture
      TexturePtr texture = TextureManager::getSingleton().getByName( m_TextureName );

      // Get the pixel buffer
      HardwarePixelBufferSharedPtr pixelBuffer = texture->getBuffer();

      // Lock the pixel buffer and get a pixel box
      pixelBuffer->lock(HardwareBuffer::HBL_DISCARD); // for best performance use HBL_DISCARD!, HBL_NORMAL otherwise
      const PixelBox& pixelBox = pixelBuffer->getCurrentLock();

      uint8* pDest = static_cast<uint8*>(pixelBox.data);

      int blue = 128;
      int green = 0;
      int red = 0;
      int alpha = 255;
      int width = m_Width;
      int height = m_Height;

      int bytesPerLine = width*4;
      for (int y=0;y<height;y++)
      {
         for (int x=0;x<bytesPerLine;x+=4)
         {
            int p1 = pixels[y*bytesPerLine+x];
            int p2 = pixels[y*bytesPerLine+x+1];
            int p3 = pixels[y*bytesPerLine+x+2];
            int p4 = pixels[y*bytesPerLine+x+3];
            pDest[y*bytesPerLine+x] = pixels[y*bytesPerLine+x];
            pDest[y*bytesPerLine+x+1] = pixels[y*bytesPerLine+x+1];
            pDest[y*bytesPerLine+x+2] = pixels[y*bytesPerLine+x+2];
//			pDest[y*bytesPerLine+x+3] = pixels[y*bytesPerLine+x+3];
         }
      }

      // Unlock the pixel buffer
      pixelBuffer->unlock();
   }
}

bool BrowserPlane::RayHitBrowser( Ogre::Entity* pentity, const Ray& ray, int& outX, int& outY )
{
   bool hit = false;
   Ogre::Real closest_distance = -1.0f;

   // mesh data to retrieve         
   size_t vertex_count;
   size_t index_count;
   Ogre::Vector3 *vertices;
   unsigned long *indices;

   // get the mesh information
   GetMeshInformation( pentity->getMesh(), vertex_count, vertices, index_count, indices,             
                       pentity->getParentNode()->getWorldPosition(),
                       pentity->getParentNode()->getWorldOrientation(),
                       pentity->getParentNode()->getScale() );

   // test for hitting individual triangles on the mesh
   bool new_closest_found = false;
   for (int i = 0; i < static_cast<int>(index_count); i += 3)
   {
       // check for a hit against this triangle
       std::pair<bool, Ogre::Real> hit = Ogre::Math::intersects(ray, vertices[indices[i]],
           vertices[indices[i+1]], vertices[indices[i+2]], true, false);

       // if it was a hit check if its the closest
       if (hit.first)
       {
           if ((closest_distance < 0.0f) ||
               (hit.second < closest_distance))
           {
               // this is the closest so far, save it off
               closest_distance = hit.second;
               new_closest_found = true;
           }
       }
   }

   // free the verticies and indicies memory
   delete[] vertices;
   delete[] indices;

   // get the parent node
   Ogre::SceneNode* browserNode = pentity->getParentSceneNode();

   // if we found a new closest raycast for this object, update the
   // closest_result before moving on to the next object.
   if ( (browserNode != 0) && new_closest_found )
   {
      Ogre::Vector3 pointOnPlane = ray.getPoint(closest_distance);
      Ogre::Quaternion quat = browserNode->_getDerivedOrientation().Inverse();
      Ogre::Vector3 result = quat * pointOnPlane;
      Ogre::Vector3 positionInWorld = quat * browserNode->_getDerivedPosition();
      Ogre::Vector3 scale = browserNode->_getDerivedScale();

      outX = (m_Width/2) - ((result.z - positionInWorld.z)/scale.z);
      outY = (m_Height/2) - ((result.y - positionInWorld.y)/scale.y);

      hit = true;
   }

   return( hit );
}

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// MovablePlane overloaded methods
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// LLEmbeddedBrowserWindowObserver overloaded methods 
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
/**
* Called to get new browser data each frame.
*/
unsigned char* BrowserPlane::GrabNewBrowserData()
{
   unsigned char* pixels = NULL;
   if (m_needsUpdate)
   {
      // Grab a page but don't reset 'needs update' flag until we've written it to the texture.
      LLMozLib::getInstance()->grabBrowserWindow(m_browserWindowId);
   }

   // Valid window and needs to be updated.
   if (m_browserWindowId && m_needsUpdate)
   {
      // Grab the pixel data.
      pixels = (unsigned char*)LLMozLib::getInstance()->getBrowserWindowPixels( m_browserWindowId );
      int actualWidth = LLMozLib::getInstance()->getBrowserRowSpan( m_browserWindowId ) / LLMozLib::getInstance()->getBrowserDepth( m_browserWindowId );
      // Flag as already updated.
      m_needsUpdate = false;
   }
   return pixels;
}


/**
* Called to save the brower window as a tga file.
* @param filename Tga file to save.
*/
void BrowserPlane::SaveTga(const std::string& filename)
{
   // Grab the pixel data.
   const unsigned char* pixels = LLMozLib::getInstance()->getBrowserWindowPixels(m_browserWindowId);
   if (pixels)
   {
      int actualWidth = LLMozLib::getInstance()->getBrowserRowSpan(m_browserWindowId)/LLMozLib::getInstance()->getBrowserDepth(m_browserWindowId);
      int height = LLMozLib::getInstance()->getBrowserHeight(m_browserWindowId);

      FILE* fd = fopen(filename.c_str(),"wb");

      short int val = 0;
      fwrite(&val,1,1,fd);

      val = 0;
      fwrite(&val,1,1,fd);

      //Type=2 means pixelDepth is 24 or 32.
      val = 2;
      fwrite(&val, 1, 1, fd );

      val = 0;
      fwrite(&val,1,1,fd);
      fwrite(&val,1,1,fd);
      fwrite(&val,1,1,fd);
      fwrite(&val,1,1,fd);
      fwrite(&val,1,1,fd);

      val = 0;
      fwrite(&val,2,1,fd);
      fwrite(&val,2,1,fd );
      fwrite(&actualWidth,2,1,fd);  //width
      fwrite(&height,2,1,fd); //height

      val = 32;  //pixelDepth
      fwrite(&val,1,1,fd);

      val = 8;
      fwrite(&val,1,1,fd);

      for (int y=height-1;y>-1;--y) //vertical flip
      {
         fwrite(pixels+y*actualWidth*4,1,actualWidth*4,fd);
      };

      fclose(fd);
   }
}

void BrowserPlane::MouseButtonLeftDown(int x, int y)
{
   // send event to LLMozLib
   LLMozLib::getInstance()->mouseDown( m_browserWindowId, x, y );
}

void BrowserPlane::MouseButtonLeftUp(int x, int y)
{
   // send event to LLMozLib
   LLMozLib::getInstance()->mouseUp( m_browserWindowId, x, y );
   // this seems better than sending focus on mouse down (still need to improve this)
   LLMozLib::getInstance()->focusBrowser( m_browserWindowId, true );
}

void BrowserPlane::MouseMove(int x, int y)
{
   // send event to LLMozLib
   LLMozLib::getInstance()->mouseMove( m_browserWindowId, x, y );
}

void BrowserPlane::KeyDown(unsigned char key)
{
   // send event to LLMozLib
   LLMozLib::getInstance()->keyPress( m_browserWindowId, key );
}

///LLEmbeddedBrowserWindowObserver events
void BrowserPlane::onPageChanged(const EventType& eventIn)
{
   // Flag that an update is required.
   m_needsUpdate = true;
}

void BrowserPlane::onNavigateBegin(const EventType& eventIn)
{
}

void BrowserPlane::onNavigateComplete(const EventType& eventIn)
{
}

void BrowserPlane::onUpdateProgress(const EventType& eventIn)
{
}

void BrowserPlane::onStatusTextChange(const EventType& eventIn)
{
}
void BrowserPlane::onLocationChange(const EventType& eventIn)
{
}

void BrowserPlane::onClickLinkHref(const EventType& eventIn)
{
}

//void BrowserPlane::AddBrowserListener(IBrowserListener* browserlistener);

void BrowserPlane::CreateMaterial()
{
   m_TextureName = "uOgreBrowserTexture";
   m_TextureName += NumberToString( m_browserWindowId );

   m_MaterialName = "uOgreBrowserMaterial";
   m_MaterialName += NumberToString( m_browserWindowId );

   // Create the texture
   TexturePtr texture = TextureManager::getSingleton().createManual( m_TextureName, // name
                                                                     ResourceGroupManager::DEFAULT_RESOURCE_GROUP_NAME,
                                                                     TEX_TYPE_2D,      // type
                                                                     m_Width,
                                                                     m_Height,         // width & height
                                                                     0,                // number of mipmaps
                                                                     PF_BYTE_BGRA,     // pixel format
                                                                     TU_DYNAMIC_WRITE_ONLY_DISCARDABLE );      // usage; should be TU_DYNAMIC_WRITE_ONLY_DISCARDABLE for
   // textures updated very often (e.g. each frame), TU_DEFAULT otherwise

   // Get the pixel buffer
   HardwarePixelBufferSharedPtr pixelBuffer = texture->getBuffer();

   // Lock the pixel buffer and get a pixel box
   pixelBuffer->lock(HardwareBuffer::HBL_DISCARD); // for best performance use HBL_DISCARD!, HBL_NORMAL otherwise
   const PixelBox& pixelBox = pixelBuffer->getCurrentLock();

   uint8* pDest = static_cast<uint8*>(pixelBox.data);

   int blue = 0;
   int green = 0;
   int red = 128;
   int alpha = 255;

   // Fill in some pixel data.
   for (size_t j = 0; j < (unsigned int)m_Width; j++)
      for (size_t i = 0; i < (unsigned int)m_Height; i++)
      {
         *pDest++ = blue;  // B
         *pDest++ = green; // G
         *pDest++ = red;   // R
         *pDest++ = alpha; // A
      }

   // Unlock the pixel buffer
   pixelBuffer->unlock();

   // Create a material using the texture
   MaterialPtr material = MaterialManager::getSingleton().create( m_MaterialName, // name
                                                                  ResourceGroupManager::DEFAULT_RESOURCE_GROUP_NAME );

   TextureUnitState* texUnit1 = material->getTechnique(0)->getPass(0)->createTextureUnitState( m_TextureName );

   //mag is causing it
   texUnit1->setTextureFiltering(FO_NONE,FO_NONE,FO_NONE);
}

String GetStartupPath()
{
   char buffer[MAX_PATH];

   GetModuleFileName(NULL, buffer, MAX_PATH);
   PathRemoveFileSpec(buffer);
   String path = buffer;

   return path;
}

String NumberToString( int number )
{
   String numberStr;
   char buffer[20];

   numberStr = itoa( number, buffer, 10 );

   return( numberStr );
}

// Get the mesh information for the given mesh.
// Code found on this forum link: http://www.ogre3d.org/wiki/index.php/RetrieveVertexData
void GetMeshInformation( const Ogre::MeshPtr mesh,
                         size_t &vertex_count,
                         Ogre::Vector3* &vertices,
                         size_t &index_count,
                         unsigned long* &indices,
                         const Ogre::Vector3 &position,
                         const Ogre::Quaternion &orient,
                         const Ogre::Vector3 &scale )
{
    bool added_shared = false;
    size_t current_offset = 0;
    size_t shared_offset = 0;
    size_t next_offset = 0;
    size_t index_offset = 0;

    vertex_count = index_count = 0;

    // Calculate how many vertices and indices we're going to need
    for (unsigned short i = 0; i < mesh->getNumSubMeshes(); ++i)
    {
        Ogre::SubMesh* submesh = mesh->getSubMesh( i );

        // We only need to add the shared vertices once
        if(submesh->useSharedVertices)
        {
            if( !added_shared )
            {
                vertex_count += mesh->sharedVertexData->vertexCount;
                added_shared = true;
            }
        }
        else
        {
            vertex_count += submesh->vertexData->vertexCount;
        }

        // Add the indices
        index_count += submesh->indexData->indexCount;
    }


    // Allocate space for the vertices and indices
    vertices = new Ogre::Vector3[vertex_count];
    indices = new unsigned long[index_count];

    added_shared = false;

    // Run through the submeshes again, adding the data into the arrays
    for ( unsigned short i = 0; i < mesh->getNumSubMeshes(); ++i)
    {
        Ogre::SubMesh* submesh = mesh->getSubMesh(i);

        Ogre::VertexData* vertex_data = submesh->useSharedVertices ? mesh->sharedVertexData : submesh->vertexData;

        if((!submesh->useSharedVertices)||(submesh->useSharedVertices && !added_shared))
        {
            if(submesh->useSharedVertices)
            {
                added_shared = true;
                shared_offset = current_offset;
            }

            const Ogre::VertexElement* posElem =
                vertex_data->vertexDeclaration->findElementBySemantic(Ogre::VES_POSITION);

            Ogre::HardwareVertexBufferSharedPtr vbuf =
                vertex_data->vertexBufferBinding->getBuffer(posElem->getSource());

            unsigned char* vertex =
                static_cast<unsigned char*>(vbuf->lock(Ogre::HardwareBuffer::HBL_READ_ONLY));

            // There is _no_ baseVertexPointerToElement() which takes an Ogre::Real or a double
            //  as second argument. So make it float, to avoid trouble when Ogre::Real will
            //  be comiled/typedefed as double:
            //      Ogre::Real* pReal;
            float* pReal;

            for( size_t j = 0; j < vertex_data->vertexCount; ++j, vertex += vbuf->getVertexSize())
            {
                posElem->baseVertexPointerToElement(vertex, &pReal);

                Ogre::Vector3 pt(pReal[0], pReal[1], pReal[2]);

                vertices[current_offset + j] = (orient * (pt * scale)) + position;
            }

            vbuf->unlock();
            next_offset += vertex_data->vertexCount;
        }


        Ogre::IndexData* index_data = submesh->indexData;
        size_t numTris = index_data->indexCount / 3;
        Ogre::HardwareIndexBufferSharedPtr ibuf = index_data->indexBuffer;

        bool use32bitindexes = (ibuf->getType() == Ogre::HardwareIndexBuffer::IT_32BIT);

        unsigned long*  pLong = static_cast<unsigned long*>(ibuf->lock(Ogre::HardwareBuffer::HBL_READ_ONLY));
        unsigned short* pShort = reinterpret_cast<unsigned short*>(pLong);


        size_t offset = (submesh->useSharedVertices)? shared_offset : current_offset;

        if ( use32bitindexes )
        {
            for ( size_t k = 0; k < numTris*3; ++k)
            {
                indices[index_offset++] = pLong[k] + static_cast<unsigned long>(offset);
            }
        }
        else
        {
            for ( size_t k = 0; k < numTris*3; ++k)
            {
                indices[index_offset++] = static_cast<unsigned long>(pShort[k]) +
                    static_cast<unsigned long>(offset);
            }
        }

        ibuf->unlock();
        current_offset = next_offset;
    }
}

