#include "DebugPrint.h"

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

#include <Windows.h>

int DebugPrint( const char* format, ... )
{
   va_list args;
   int len;
   char * buffer;

   va_start( args, format );
   len = _vscprintf( format, args ) // _vscprintf doesn't count
                               + 1; // terminating '\0'
   buffer = (char*)malloc( len * sizeof(char) );
   vsprintf( buffer, format, args );
   ::OutputDebugStringA( buffer );
   free( buffer );

   return( len );
}


