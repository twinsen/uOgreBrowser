#pragma once

int DebugPrint( const char* format, ... );


