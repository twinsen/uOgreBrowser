#ifndef PlayState_H
#define PlayState_H

#include <OgreCamera.h>

#include "GameState.h"
#include "PauseState.h"
#include "BrowserPlane.h"

class PlayState : public GameState
{
public:
   ~PlayState( void );

   void enter( void );
   void exit( void );

   void pause( void );
   void resume( void );
   void update( unsigned long lTimeElapsed );

   void keyPressed( const OIS::KeyEvent &e );
   void keyReleased( const OIS::KeyEvent &e );

   void mouseMoved( const OIS::MouseEvent &e );
   void mousePressed( const OIS::MouseEvent &e, OIS::MouseButtonID id );
   void mouseReleased( const OIS::MouseEvent &e, OIS::MouseButtonID id );

   static PlayState* getSingletonPtr( void );
private:
   PlayState( void )
   {
   }
   PlayState( const PlayState& )
   {
   }
   PlayState & operator = ( const PlayState& );

   bool MouseInBrowser( int x, int y, int width, int height, int& outX, int& outY, int& browserIndex );

   Ogre::Root           *mRoot;
   Ogre::Camera         *mCamera;
   Ogre::SceneNode      *mCamNode;   // The SceneNode the camera is currently attached to
   Ogre::SceneManager   *mSceneMgr;
   Ogre::Viewport       *mViewport;
   Ogre::MaterialManager *mMaterialMgr;
   Ogre::OverlayManager *mOverlayMgr;
   Ogre::Overlay        *mInfoOverlay;
   Ogre::Overlay        *mPlayOverlay;
   Ogre::Overlay        *mMouseOverlay;
   Ogre::OverlayElement *mMousePointer;
   Ogre::OverlayElement *mInfoInstruction;
   Ogre::OverlayElement *mInfoNotification;

   OIS::Keyboard        *mInputDevice;

   bool mFreeLook;
   Ogre::Real mRotate;          // The rotate constant
   Ogre::Real mMove;            // The movement constant

   // browser specific data
   int mBrowserWithFocus;
   Ogre::SceneNode* mBrowserNode[2];
   Ogre::BrowserPlane* mBrowserPlane[2];

   // map of entity name to index of the browser
   typedef std::map<Ogre::String,int> TBrowserMap;
   TBrowserMap m_BrowserMap;
   // end-browser specific data

   bool mContinue;        // Whether to continue rendering or not
   Ogre::Vector3 mDirection;    // Value to move in the correct direction

   static PlayState *mPlayState;
};
#endif

