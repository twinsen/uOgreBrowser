#pragma once

#include <Ogre.h>
#include <llmozlib.h>
#include <Windows.h>

namespace Ogre
{
   class BrowserPlane : public Ogre::MovablePlane,
                        public LLEmbeddedBrowserWindowObserver
   {
   public:
      //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
      //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
      // BrowserPlane specific methods
      //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
      //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
      BrowserPlane( const String& name, const String& startingURL, const Vector3 &rkNormal, Real fConstant, Real width, Real height, HWND hwnd );

      virtual ~BrowserPlane();

      void UpdateMaterial();

      bool RayHitBrowser( Ogre::Entity* pentity, const Ray& ray, int& outX, int& outY );

      String m_PlaneName;
      String m_TextureName;
      String m_MaterialName;

      int m_browserWindowId;  ///< LLMozLib Browser window Id.

      //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
      //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
      // MovablePlane overloaded methods
      //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
      //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

      //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
      //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
      // LLEmbeddedBrowserWindowObserver overloaded methods 
      //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
      //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
      /**
      * Called to get new browser data each frame.
      */
      unsigned char* GrabNewBrowserData();

      /**
      * Called to save the brower window as a tga file.
      * @param filename Tga file to save.
      */
      void SaveTga(const std::string& filename);

      void MouseButtonLeftDown(int x, int y);
      void MouseButtonLeftUp(int x, int y);
      void MouseMove(int x, int y);
      void KeyDown(unsigned char key);

      ///LLEmbeddedBrowserWindowObserver events
      void onPageChanged(const EventType& eventIn);
      void onNavigateBegin(const EventType& eventIn);
      void onNavigateComplete(const EventType& eventIn);
      void onUpdateProgress(const EventType& eventIn);
      void onStatusTextChange(const EventType& eventIn);
      void onLocationChange(const EventType& eventIn);
      void onClickLinkHref(const EventType& eventIn);

      //void AddBrowserListener(IBrowserListener* browserlistener);

   protected:
      bool m_needsUpdate;     ///< Flag to indicate if browser texture needs an update.
      HWND m_hWnd;            ///< Window handle.

      Real m_Width;
      Real m_Height;

      /**
      * Creates the uOgreBrowser material.
      */
      void CreateMaterial();
   };
};
