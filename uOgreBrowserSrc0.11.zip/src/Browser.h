/*
-----------------------------------------------------------------------------
This source file is part of uOgreBrowser.
For the latest info, see http://www.ogre3d.org/wiki/index.php/UOgreBrowser

Copyright (c) 2006 Ryan De Boer.

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU Lesser General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later
version.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License along with
this program; if not, write to the Free Software Foundation, Inc., 59 Temple
Place - Suite 330, Boston, MA 02111-1307, USA, or go to
http://www.gnu.org/copyleft/lesser.txt.
-----------------------------------------------------------------------------
*/

#pragma once

#include <windows.h>
#include <vector>
#include <Ogre.h>
#include "IFrameListener.h"
#include "IBrowserListener.h"

namespace uOgreBrowser
{
    class EmbeddedBrowserObserver;

    /**
    * Encapsulates the browser and Ogre window.
    */
    class Browser
    {
    public:

        /**
        * Returns the single instance of the Browser. It is not a singleton 
        * by choice. Need to improve hwnd to instance mapping in WinProc to make it 
        * non-singleton.
        * @return Browser.
        */
        static Browser* GetInstance();

        /**
        * Destructor.
        */
        ~Browser() {};

        /**
        * Called to start processing messages.
        */
        void Run();

        /**
        * Adds a framelistener to be notified when frame events occur.
        * @param framelistener Listener for events.
        */
        void AddFrameListener(IFrameListener* framelistener);

        /**
        * Adds a browserlistener to be notified when browser events occur.
        * @param browserlistener Listener for events.
        */
        void AddBrowserListener(IBrowserListener* browserlistener);

        /**
        * Called to save the brower window as a tga file.
        * @param filename Tga file to save.
        */
        void SaveTga(const std::string& filename);

        void UpdateThis(const unsigned char* pixels);

        HWND GetHwnd() {return m_hWnd;}

    private:
        /**
        * Constructor.
        * @return Browser.
        */
        Browser();

        /**
        * Creates the win32 window.
        */
        void CreateWin32Window();

        /**
        * Initializes Ogre.
        */
        void OgreInit();

        /**
        * Shows the win32 window.
        */
        void ShowWindow();

        /**
        * Does the win32 message queue loop.
        */
        void MessageLoop();

        /**
        * Creates the uOgreBrowser material.
        */
        void CreateMaterial();

        /**
        * Updates the uOgreBrowser material.
        */
        void UpdateMaterial();

        /**
        * WindowProc that processes the messages from the message queue.
        * @param hWnd Windows handle.
        * @param msg Specifies the Windows message to be processed. 
        * @param wParam Specifies additional message-dependent information. 
        * @param lParam Specifies additional message-dependent information. 
        * @return Depends on the message sent.
        */
        static LRESULT CALLBACK WindowProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

        static Browser* sm_pInstance;     ///< The single instance.

        HWND m_hWnd;  ///< Windows handle.
        EmbeddedBrowserObserver* m_embeddedBrowserObvserver; ///< Communicates with LLMozLib.
        std::vector<IFrameListener*> m_frameListeners;   ///< List of objects that want to be notified of frame events.
    };
}
