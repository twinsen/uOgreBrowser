/*
-----------------------------------------------------------------------------
This source file is part of uOgreBrowser.
For the latest info, see http://www.ogre3d.org/wiki/index.php/UOgreBrowser

Copyright (c) 2006 Ryan De Boer.

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU Lesser General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later
version.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License along with
this program; if not, write to the Free Software Foundation, Inc., 59 Temple
Place - Suite 330, Boston, MA 02111-1307, USA, or go to
http://www.gnu.org/copyleft/lesser.txt.
-----------------------------------------------------------------------------
*/

#include "EmbeddedBrowserObserver.h"
#include <sstream>
#include "Utilities\Application.h"

#include "Browser.h" //no

#define WIDTH 799
#define HEIGHT 600

namespace uOgreBrowser
{

EmbeddedBrowserObserver::EmbeddedBrowserObserver(HWND hWnd) : m_needsUpdate(true), m_browserWindowId(0), m_hWnd(hWnd)
{
    Initialize();
}

void EmbeddedBrowserObserver::Initialize()
{
    // Create a single browser window and set things up.

    std::string profileBaseDir = uOgreBrowser::Utilities::Application::GetStartupPath();

    // Get window title.
    char title[MAX_PATH];
    GetWindowText(m_hWnd,title,MAX_PATH);
    std::string profileName = title;

    // Get window dimensions.
    RECT windowClientArea;
    GetClientRect(m_hWnd, &windowClientArea);
    int browserWindowWidth = windowClientArea.right;
    int browserWindowHeight = windowClientArea.bottom;

    browserWindowWidth = WIDTH;
    browserWindowHeight = HEIGHT;


    // Setup home URL.
    std::stringstream buffer;
    buffer << "file://" << profileBaseDir << "//a.html";
    std::string homeUrl = buffer.str();

//    homeUrl = "http://www.ogre3d.org";

    LLMozLib::getInstance()->init(profileBaseDir,profileName);
    m_browserWindowId = LLMozLib::getInstance()->createBrowserWindow(m_hWnd,browserWindowWidth,browserWindowHeight);

    // Tell LLMozLib about the size of the browser window.
    LLMozLib::getInstance()->setSize(m_browserWindowId,browserWindowWidth,browserWindowHeight);

    // Observer events that LLMozLib emits.
    LLMozLib::getInstance()->addObserver(m_browserWindowId,this);

    // Append details to agent string.
    LLMozLib::getInstance()->setBrowserAgentId(profileName);

    // Go to the "home page".
    LLMozLib::getInstance()->navigateTo(m_browserWindowId,homeUrl);
}



unsigned char* EmbeddedBrowserObserver::GrabNewBrowserData()
{
    unsigned char* pixels = NULL;
    if (m_needsUpdate)
    {
        // Grab a page but don't reset 'needs update' flag until we've written it to the texture.
        LLMozLib::getInstance()->grabBrowserWindow(m_browserWindowId);
    }

    // Valid window and needs to be updated.
    if (m_browserWindowId && m_needsUpdate)
    {
        // Grab the pixel data.
        pixels = (unsigned char*)LLMozLib::getInstance()->getBrowserWindowPixels( m_browserWindowId );
        int actualWidth = LLMozLib::getInstance()->getBrowserRowSpan( m_browserWindowId ) / LLMozLib::getInstance()->getBrowserDepth( m_browserWindowId );
        // Flag as already updated.
        m_needsUpdate = false;
    }
    return pixels;
}

void EmbeddedBrowserObserver::SaveTga(const std::string& filename)
{
    // Grab the pixel data.
    const unsigned char* pixels = LLMozLib::getInstance()->getBrowserWindowPixels(m_browserWindowId);
    if (pixels)
    {
        int actualWidth = LLMozLib::getInstance()->getBrowserRowSpan(m_browserWindowId)/LLMozLib::getInstance()->getBrowserDepth(m_browserWindowId);
        int height = LLMozLib::getInstance()->getBrowserHeight(m_browserWindowId);
//        int actualWidth = WIDTH;
//        int height = HEIGHT;

        FILE* fd = fopen(filename.c_str(),"wb");

        short int val = 0;
        fwrite(&val,1,1,fd);

        val = 0;
        fwrite(&val,1,1,fd);

        //Type=2 means pixelDepth is 24 or 32.
        val = 2;
        fwrite(&val, 1, 1, fd );

        val = 0;
        fwrite(&val,1,1,fd);
        fwrite(&val,1,1,fd);
        fwrite(&val,1,1,fd);
        fwrite(&val,1,1,fd);
        fwrite(&val,1,1,fd);

        val = 0;
        fwrite(&val,2,1,fd);
        fwrite(&val,2,1,fd );
        fwrite(&actualWidth,2,1,fd);  //width
        fwrite(&height,2,1,fd); //height

        val = 32;  //pixelDepth
        fwrite(&val,1,1,fd);

        val = 8;
        fwrite(&val,1,1,fd);

        for (int y=height-1;y>-1;--y) //vertical flip
        {
            fwrite(pixels+y*actualWidth*4,1,actualWidth*4,fd);
        };

        fclose(fd);
    }
}

void EmbeddedBrowserObserver::onPageChanged(const EventType& eventIn)
{
    // Flag that an update is required.
    m_needsUpdate = true;
}

void EmbeddedBrowserObserver::onNavigateComplete(const EventType& eventIn)
{
    OutputDebugString(eventIn.getEventUri().c_str());
    for (unsigned int i=0;i<m_browserListeners.size();i++)
    {
        m_browserListeners[i]->OnNavigateComplete(eventIn.getEventUri());
    }
}

void EmbeddedBrowserObserver::onClickLinkHref(const EventType& eventIn)
{
    for (unsigned int i=0;i<m_browserListeners.size();i++)
    {
        m_browserListeners[i]->OnClickLinkHref(eventIn.getStringValue());
    }
}

void EmbeddedBrowserObserver::MouseButtonLeftDown(int x, int y)
{
    // send event to LLMozLib
    LLMozLib::getInstance()->mouseDown(m_browserWindowId,x,y);
}

void EmbeddedBrowserObserver::MouseButtonLeftUp(int x, int y)
{
    // send event to LLMozLib
    LLMozLib::getInstance()->mouseUp(m_browserWindowId,x,y);
    // this seems better than sending focus on mouse down (still need to improve this)
    LLMozLib::getInstance()->focusBrowser(m_browserWindowId,true);
}

void EmbeddedBrowserObserver::MouseMove(int x, int y)
{
    // send event to LLMozLib
    LLMozLib::getInstance()->mouseMove(m_browserWindowId,x,y);
}

void EmbeddedBrowserObserver::KeyDown(unsigned char key)
{
    // send event to LLMozLib
    LLMozLib::getInstance()->keyPress(m_browserWindowId,key);
}

        void EmbeddedBrowserObserver::AddBrowserListener(IBrowserListener* browserlistener)
        {
            m_browserListeners.push_back(browserlistener);
        }


}