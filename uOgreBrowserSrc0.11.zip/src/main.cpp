/*
-----------------------------------------------------------------------------
This source file is part of uOgreBrowser.
For the latest info, see http://www.ogre3d.org/wiki/index.php/UOgreBrowser

Copyright (c) 2006 Ryan De Boer.

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU Lesser General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later
version.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License along with
this program; if not, write to the Free Software Foundation, Inc., 59 Temple
Place - Suite 330, Boston, MA 02111-1307, USA, or go to
http://www.gnu.org/copyleft/lesser.txt.
-----------------------------------------------------------------------------
*/

#include "Browser.h"
#include "TestScene.h"

using namespace uOgreBrowser;

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR lpCmdLine, int nCmdShow)
{
    Browser* browser = Browser::GetInstance();
    TestScene* testScene = new TestScene(browser);
    browser->AddFrameListener(testScene);
    browser->AddBrowserListener(testScene);
    browser->Run();
	return 0;
}

/*
#include <windows.h>
#include "EmbeddedBrowserObserver.h"

//#region proc
static LRESULT CALLBACK WindowProc( HWND   hWnd, 
                                   UINT   msg, 
                                   WPARAM wParam, 
                                   LPARAM lParam )
{
    switch( msg )
    {
    case WM_KEYDOWN:
        {
            switch( wParam )
            {

            case VK_ESCAPE:
                PostQuitMessage(0);
                break;
            }
        }
        break;

    case WM_CLOSE:
    case WM_DESTROY:
        {
            PostQuitMessage(0);
        }
        break;

    default:
        {
            return DefWindowProc( hWnd, msg, wParam, lParam );
        }
        break;
    }

    return 0;
}
//#endregion

int APIENTRY WinMain(HINSTANCE hInstance1, HINSTANCE hPrevInstance, LPTSTR lpCmdLine, int nCmdShow)
{

    //#region win
    WNDCLASSEX winClass;
    MSG        uMsg;
    HWND hWnd;

    memset(&uMsg,0,sizeof(uMsg));

    HINSTANCE hInstance = GetModuleHandle(NULL);

    winClass.lpszClassName = "MY_WINDOWS_CLASS";
    winClass.cbSize        = sizeof(WNDCLASSEX);
    winClass.style         = CS_HREDRAW | CS_VREDRAW;
    winClass.lpfnWndProc   = WindowProc;
    winClass.hInstance     = hInstance;
    winClass.hIcon	       = LoadIcon(hInstance, (LPCTSTR)IDI_APPLICATION);
    winClass.hIconSm	   = LoadIcon(hInstance, (LPCTSTR)IDI_APPLICATION);
    winClass.hCursor       = LoadCursor(NULL, IDC_ARROW);
    winClass.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
    winClass.lpszMenuName  = NULL;
    winClass.cbClsExtra    = 0;
    winClass.cbWndExtra    = 0;

    RegisterClassEx(&winClass);

    hWnd = CreateWindowEx( NULL, "MY_WINDOWS_CLASS", 
        "SomeOtherName",
        WS_OVERLAPPEDWINDOW | WS_VISIBLE,
        0, 0, 900-92, 700-73, NULL, NULL, hInstance, NULL );
    ShowWindow( hWnd, 1 );
    UpdateWindow( hWnd );
    //#endregion

    EmbeddedBrowserObserver* embeddedBrowserObvserver = new EmbeddedBrowserObserver(hWnd);


    while( uMsg.message != WM_QUIT )
    {
        if( PeekMessage( &uMsg, NULL, 0, 0, PM_REMOVE ) )
        { 
            TranslateMessage( &uMsg );
            DispatchMessage( &uMsg );
        }
        else
        {
            embeddedBrowserObvserver->GrabNewBrowserData();
        }
    }

    return 0;
}
*/