/*
-----------------------------------------------------------------------------
This source file is part of uOgreBrowser.
For the latest info, see http://www.ogre3d.org/wiki/index.php/UOgreBrowser

Copyright (c) 2006 Ryan De Boer.

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU Lesser General Public License as published by the Free Software
Foundation; either version 2 of the License, or (at your option) any later
version.

This program is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License along with
this program; if not, write to the Free Software Foundation, Inc., 59 Temple
Place - Suite 330, Boston, MA 02111-1307, USA, or go to
http://www.gnu.org/copyleft/lesser.txt.
-----------------------------------------------------------------------------
*/

#include "Browser.h"
#include <Ogre.h>
#include "EmbeddedBrowserObserver.h"
#include "Materials\OgreColorFactory.h"

#include "ogre2d-main.h"

using namespace Ogre;

#define WIDTH 800
#define HEIGHT 600

namespace uOgreBrowser
{
    //#region Construction

    Browser* Browser::sm_pInstance = NULL;// initialize pointer

    Browser* Browser::GetInstance() 
    {
        if (sm_pInstance == NULL)
        {  
            sm_pInstance = new Browser();
        }
        return sm_pInstance;
    }

    Browser::Browser() : m_hWnd(NULL)
    {
        CreateWin32Window();
        OgreInit();
        m_embeddedBrowserObvserver = new EmbeddedBrowserObserver(m_hWnd);
        CreateMaterial();
    }

    //#endregion

    //#region CreateWin32Window

    void Browser::CreateWin32Window()
    {
        WNDCLASSEX winClass;

        HINSTANCE hInstance = GetModuleHandle(NULL);

        winClass.lpszClassName = "U_OGRE_BROWSER_WINDOW_CLASS";
        winClass.cbSize        = sizeof(WNDCLASSEX);
        winClass.style         = CS_HREDRAW | CS_VREDRAW;
        winClass.lpfnWndProc   = WindowProc;
        winClass.hInstance     = hInstance;
        winClass.hIcon	       = LoadIcon(hInstance, (LPCTSTR)IDI_APPLICATION);
        winClass.hIconSm	   = LoadIcon(hInstance, (LPCTSTR)IDI_APPLICATION);
        winClass.hCursor       = LoadCursor(NULL, IDC_ARROW);
        winClass.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
        winClass.lpszMenuName  = NULL;
        winClass.cbClsExtra    = 0;
        winClass.cbWndExtra    = 0;

        RegisterClassEx(&winClass);

        m_hWnd = CreateWindowEx(NULL, "U_OGRE_BROWSER_WINDOW_CLASS", "uOgreBrowser", WS_OVERLAPPEDWINDOW, 
            0, 0, 808, 627, NULL, NULL, hInstance, NULL);
    }

    //#endregion

    //#region ShowWindow

    void Browser::ShowWindow()
    {
        ::ShowWindow(m_hWnd,1);
        UpdateWindow(m_hWnd);
    }

    //#endregion

    //#region CreateMaterial

    void Browser::CreateMaterial()
    {
	int width = WIDTH;
	int height = HEIGHT;

	// Create the texture
	TexturePtr texture = TextureManager::getSingleton().createManual(
		"uOgreBrowserTexture", // name
		ResourceGroupManager::DEFAULT_RESOURCE_GROUP_NAME,
		TEX_TYPE_2D,      // type
		width, height,         // width & height
		0,                // number of mipmaps
		PF_BYTE_BGRA,     // pixel format
		TU_DYNAMIC_WRITE_ONLY_DISCARDABLE);      // usage; should be TU_DYNAMIC_WRITE_ONLY_DISCARDABLE for
	// textures updated very often (e.g. each frame), TU_DEFAULT otherwise

	// Get the pixel buffer
	HardwarePixelBufferSharedPtr pixelBuffer = texture->getBuffer();

	// Lock the pixel buffer and get a pixel box
	pixelBuffer->lock(HardwareBuffer::HBL_DISCARD); // for best performance use HBL_DISCARD!, HBL_NORMAL otherwise
	const PixelBox& pixelBox = pixelBuffer->getCurrentLock();

	uint8* pDest = static_cast<uint8*>(pixelBox.data);

	int blue = 0;
	int green = 0;
	int red = 128;
	int alpha = 255;

	// Fill in some pixel data.
	for (size_t j = 0; j < (unsigned int)width; j++)
		for(size_t i = 0; i < (unsigned int)height; i++)
		{
			*pDest++ = blue;  // B
			*pDest++ = green; // G
			*pDest++ = red;   // R
			*pDest++ = alpha; // A
		}

		// Unlock the pixel buffer
		pixelBuffer->unlock();

	// Create a material using the texture
	MaterialPtr material = MaterialManager::getSingleton().create(
		"uOgreBrowserMaterial", // name
		ResourceGroupManager::DEFAULT_RESOURCE_GROUP_NAME);

	TextureUnitState* texUnit1 = material->getTechnique(0)->getPass(0)->createTextureUnitState("uOgreBrowserTexture");

    //mag is causing it
    texUnit1->setTextureFiltering(FO_NONE,FO_NONE,FO_NONE);
//    texUnit1->setTextureFiltering(FO_NONE,FO_NONE,FO_NONE);
//    material->setTextureFiltering(TFO_NONE);
//    material->setTextureAnisotropy(0);

    }

    //#endregion

    //#region UpdateMaterial

    void Browser::UpdateMaterial()
    {
        unsigned char* pixels = m_embeddedBrowserObvserver->GrabNewBrowserData();

//        m_embeddedBrowserObvserver->SaveTga("oime.tga");

        if (pixels!=NULL)
        {
	int width = WIDTH;
	int height = HEIGHT;

	// Get the texture
	TexturePtr texture = TextureManager::getSingleton().getByName("uOgreBrowserTexture");

	// Get the pixel buffer
	HardwarePixelBufferSharedPtr pixelBuffer = texture->getBuffer();

	// Lock the pixel buffer and get a pixel box
	pixelBuffer->lock(HardwareBuffer::HBL_DISCARD); // for best performance use HBL_DISCARD!, HBL_NORMAL otherwise
	const PixelBox& pixelBox = pixelBuffer->getCurrentLock();

	uint8* pDest = static_cast<uint8*>(pixelBox.data);

	int blue = 128;
	int green = 0;
	int red = 0;
	int alpha = 255;

	// Fill in some pixel data.

    //m_embeddedBrowserObvserver->SaveTga("testme3.tga");
   
    //for (int i=0;i<width*height*4;i++)
    //{
    //    pDest[i] = pixels[i];
    //}

    int bytesPerLine = width*4;
	for (int y=0;y<height;y++)
	{
		for (int x=0;x<bytesPerLine;x+=4)
		{
			int p1 = pixels[y*bytesPerLine+x];
			int p2 = pixels[y*bytesPerLine+x+1];
			int p3 = pixels[y*bytesPerLine+x+2];
			int p4 = pixels[y*bytesPerLine+x+3];
			pDest[y*bytesPerLine+x] = pixels[y*bytesPerLine+x];
			pDest[y*bytesPerLine+x+1] = pixels[y*bytesPerLine+x+1];
			pDest[y*bytesPerLine+x+2] = pixels[y*bytesPerLine+x+2];
//			pDest[y*bytesPerLine+x+3] = pixels[y*bytesPerLine+x+3];
		}
	}


    /*
    int bytesPerLine = width*4;
	for (int y=0;y<height;y++)
	{
		for (int x=0;x<bytesPerLine;x+=4)
		{
			int p1 = pixels[y*bytesPerLine+x];
			int p2 = pixels[y*bytesPerLine+x+1];
			int p3 = pixels[y*bytesPerLine+x+2];
			int p4 = pixels[y*bytesPerLine+x+3];
			pDest[y*bytesPerLine+x] = pixels[y*bytesPerLine+x];
//			pDest[y*bytesPerLine+x+1] = pixels[y*bytesPerLine+x+1];
//			pDest[y*bytesPerLine+x+2] = pixels[y*bytesPerLine+x+2];
//			pDest[y*bytesPerLine+x+3] = pixels[y*bytesPerLine+x+3];
		}
            std::stringstream buffer;
            buffer << "y: "<<y<<" x: "<<x<<std::endl;
            OutputDebugString(buffer.str().c_str());
	}
    */




		// Unlock the pixel buffer
		pixelBuffer->unlock();
        }
    }

    //#endregion

    //#region UpdateThis

    void Browser::UpdateThis(const unsigned char* pixels)
    {
//        if (pixels==NULL)
//        {
//            return;
//        }
//
//        short int width=801;
//        short int height=600;
//        unsigned char pixelDepth = 32;
//
//
//        	// Get the texture
//	TexturePtr texture = TextureManager::getSingleton().getByName("uOgreBrowserTexture");
//
//	// Get the pixel buffer
//	HardwarePixelBufferSharedPtr pixelBuffer = texture->getBuffer();
//
//	// Lock the pixel buffer and get a pixel box
//	pixelBuffer->lock(HardwareBuffer::HBL_DISCARD); // for best performance use HBL_DISCARD!, HBL_NORMAL otherwise
//	const PixelBox& pixelBox = pixelBuffer->getCurrentLock();
//
//	uint8* pDest = static_cast<uint8*>(pixelBox.data);
//
//	int blue = 128;
//	int green = 0;
//	int red = 0;
//	int alpha = 255;
//
//	// Fill in some pixel data.
//
//
//
//    int bytesPerLine = width*4;
//	for (int y=0;y<height;y++)
//	{
//		for (int x=0;x<bytesPerLine;x+=4)
//		{
//			int p1 = pixels[y*bytesPerLine+x];
//			int p2 = pixels[y*bytesPerLine+x+1];
//			int p3 = pixels[y*bytesPerLine+x+2];
//			int p4 = pixels[y*bytesPerLine+x+3];
//			pDest[y*bytesPerLine+x] = pixels[y*bytesPerLine+x];
//			pDest[y*bytesPerLine+x+1] = pixels[y*bytesPerLine+x+1];
//			pDest[y*bytesPerLine+x+2] = pixels[y*bytesPerLine+x+2];
////			pDest[y*bytesPerLine+x+3] = pixels[y*bytesPerLine+x+3];
//		}
//	}
//
//
//
//
//		// Unlock the pixel buffer
//		pixelBuffer->unlock();
    }

    //#endregion

    //#region MessageLoop

    void Browser::MessageLoop()
    {
        /*
                Root* root = Root::getSingletonPtr();
        SceneManager* sceneManager = root->getSceneManager("generic");
                        Ogre2dManager* ogre2dManager=new Ogre2dManager;
ogre2dManager->init(sceneManager, Ogre::RENDER_QUEUE_BACKGROUND, true);
*/


        MSG uMsg;
        memset(&uMsg,0,sizeof(uMsg));

        while (uMsg.message != WM_QUIT )
        {
            if (PeekMessage(&uMsg, NULL, 0, 0, PM_REMOVE))
            { 
                TranslateMessage(&uMsg);
                DispatchMessage(&uMsg);
            }
            else
            {
                UpdateMaterial();
                for (unsigned int i=0;i<sm_pInstance->m_frameListeners.size();i++)
                {
                    sm_pInstance->m_frameListeners[i]->BeginFrame();
                }

//			ogre2dManager->spriteBltFull("uOgreBrowserTexture", -1.0, -1.0, 1.0, 1.0, 0,1,1,0);

                Ogre::Root::getSingletonPtr()->renderOneFrame();
                for (unsigned int i=0;i<sm_pInstance->m_frameListeners.size();i++)
                {
                    sm_pInstance->m_frameListeners[i]->EndFrame();
                }
            }
        }
    }

    //#endregion

    //#region WindowProc

    LRESULT CALLBACK Browser::WindowProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
    {
        POINT point;
        GetCursorPos(&point);

        RECT rect;
        GetWindowRect(hWnd,&rect);
        int x = point.x-rect.left-4;
        int y = point.y-rect.top-23;
        if (x<0)
        {
            x=0;
        }
        if (y<0)
        {
            y=0;
        }

        switch( msg )
        {
        case WM_KEYDOWN:
            {
                
                unsigned char key = (unsigned char)wParam;
                Browser::GetInstance()->m_embeddedBrowserObvserver->KeyDown(key);

                switch( wParam )
                {
//                case 'A':
//                    Browser::GetInstance()->m_embeddedBrowserObvserver->SaveTga("oime.tga");
//                    break;

                case VK_ESCAPE:
                    PostQuitMessage(0);
                    break;
                }
                
            }
            break;

        case WM_LBUTTONDOWN:
            {
                Browser::GetInstance()->m_embeddedBrowserObvserver->MouseButtonLeftDown(x,y);
            }
            break;
        case WM_LBUTTONUP:
            {
                Browser::GetInstance()->m_embeddedBrowserObvserver->MouseButtonLeftUp(x,y);
            }
            break;

        case WM_MOUSEMOVE:
            {
                Browser::GetInstance()->m_embeddedBrowserObvserver->MouseMove(x,y);
            }
            break;

        case WM_CLOSE:
        case WM_DESTROY:
            {
                PostQuitMessage(0);
            }
            break;

        default:
            {
                return DefWindowProc( hWnd, msg, wParam, lParam );
            }
            break;
        }

        return 0;
    }

    //#endregion

    //#region Run

    void Browser::Run()
    {
        ShowWindow();
        MessageLoop();
    }

    //#endregion

    //#region OgreInit

    void Browser::OgreInit()
    {
        // Tell Root not to load from any plugins or settings file.
        Root *root = new Root("", "");

        // Load feature plugins. Scene managers will register themselves for all scene 
        // types they support.
        root->loadPlugin("Plugin_CgProgramManager");
        root->loadPlugin("Plugin_OctreeSceneManager");
        root->loadPlugin("RenderSystem_GL");
        root->loadPlugin("RenderSystem_Direct3D9");

        // Setup render system.
        RenderSystemList *rList = root->getAvailableRenderers();
        RenderSystemList::iterator it = rList->begin();
        RenderSystem *rSys = 0;
        bool useOpenGL = false;

        while (it != rList->end())
        {
            rSys = *(it++);
            std::string name = rSys->getName();

            if (useOpenGL && rSys->getName().find("OpenGL")!=-1)
            {
                root->setRenderSystem(rSys);
                break;
            }
            else if (!useOpenGL && rSys->getName().find("Direct3D9")!=-1)
            {
                root->setRenderSystem(rSys);
                break;
            }
        }

        // We can initialize Root here if we want. "false" tells Root NOT to create
        // a render window for us.
        root->initialise(false);

        // Required to set up BaseWhiteNoLighting and default material settings.
        MaterialManager::getSingletonPtr()->initialise();

        NameValuePairList misc;
        misc["externalWindowHandle"] = StringConverter::toString((size_t)m_hWnd);

        // Set up the render window with all default params.
        RenderWindow *window = rSys->createRenderWindow(
            "uOgreBrowser",	// Window title.
            800,		// Window width, in pixels.
            600,		// Window height, in pixels.
            false,		// Fullscreen or not.
            &misc);	    // Use defaults for all other values.

        // From here you can set up your camera and viewports as normal.
        // Get a pointer to the default base scene manager.
        SceneManager *sceneMgr = root->createSceneManager(ST_GENERIC, "generic");

        // Bright.
        sceneMgr->setAmbientLight(ColourValue(1,1,1));

        // Create a single camera, and a viewport that takes up the whole window (default behavior).
        Camera* camera = sceneMgr->createCamera("MainCam");
        camera->setPosition(150,20,0);
        camera->setDirection(-150,20,0);
        Viewport* viewport = window->addViewport(camera);
        viewport->setDimensions(0.0f, 0.0f, 1.0f, 1.0f);
        camera->setAspectRatio((float)viewport->getActualWidth() / (float) viewport->getActualHeight());
        camera->setFarClipDistance(1000.0f);
        camera->setNearClipDistance(5.0f);

        // Clear color.
        window->getViewport(0)->setBackgroundColour(Ogre::ColourValue(1,0,0,1));
    }
    //#endregion

    //#region AddFrameListener

    void Browser::AddFrameListener(IFrameListener* frameListener)
    {
        m_frameListeners.push_back(frameListener);
    }

    //#endregion

        void Browser::AddBrowserListener(IBrowserListener* browserlistener)
        {
            m_embeddedBrowserObvserver->AddBrowserListener(browserlistener);
        }

        void Browser::SaveTga(const std::string& filename)
        {
            m_embeddedBrowserObvserver->SaveTga(filename);
        }

}
