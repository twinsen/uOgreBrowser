Thanks for downloading the Awesomium v1.0 SDK for Win32 MSVC8!

The contents of this SDK are licensed under the LGPL, see LICENSE.txt for more information.

Using this Library:
- Include 'WebCore.h' in your application
- Link against 'Awesomium.lib'
- Copy 'Awesomium.dll' and 'icudt38.dll' to your application's working directory.

For debug linkage: use 'Awesomium_d.lib' and 'Awesomium_d.dll' instead.


You can keep informed of future updates to Awesomium by visiting: <http://princeofcode.com/awesomium.php>