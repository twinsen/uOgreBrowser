#pragma once

#include <Ogre.h>
#include <OgreTextAreaOverlayElement.h>
#include "IFrameListener.h"
#include "IBrowserListener.h"

namespace uOgreBrowser
{
    class Browser;

	/**
	 * This is an Ogre scene containing a robot to test with.
	 */
    class TestScene : public IFrameListener, public IBrowserListener
	{
	public:
        TestScene(Browser* browser);
		~TestScene() {};

        /**
        * Called before a frame is rendered.
        */
        void BeginFrame();
        /**
        * Called after a frame is rendered.
        */
        void EndFrame() {};

        /**
        * Called after navigation to a webpage is complete.
        */
        void OnNavigateComplete(std::string eventUri);
        /**
        * Called when clicked a webpage link.
        */
        void OnClickLinkHref(std::string value);

	private:
        void CreateRobot();
        void CreateOverlay();
        void CreateBackground();
        void CreateTextOverlay();

        void ChangeRobotTexture(std::string textureName);
        void ToggleRobotVisibility();
        void ChangeText(std::string text);

        /**
        * Called in response to browser events.
        * @param event Event string to parse.
        */
        void ProcessEvent(std::string event);

        Ogre::Entity* m_robotEntity;
        Ogre::TextAreaOverlayElement* m_textArea;

        Browser* m_browser;
	};

}
