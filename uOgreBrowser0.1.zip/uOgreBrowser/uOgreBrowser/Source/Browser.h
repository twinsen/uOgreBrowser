#pragma once

#include <windows.h>
#include <vector>
#include <Ogre.h>
#include "IFrameListener.h"
#include "IBrowserListener.h"

namespace uOgreBrowser
{
    class EmbeddedBrowserObserver;

    /**
    * Encapsulates the browser and Ogre window.
    */
    class Browser
    {
    public:

        /**
        * Returns the single instance of the Browser. It is not a singleton 
        * by choice. Need to improve hwnd to instance mapping in WinProc to make it 
        * non-singleton.
        * @return Browser.
        */
        static Browser* GetInstance();

        /**
        * Destructor.
        */
        ~Browser() {};

        /**
        * Called to start processing messages.
        */
        void Run();

        /**
        * Adds a framelistener to be notified when frame events occur.
        * @param framelistener Listener for events.
        */
        void AddFrameListener(IFrameListener* framelistener);

        /**
        * Adds a browserlistener to be notified when browser events occur.
        * @param browserlistener Listener for events.
        */
        void AddBrowserListener(IBrowserListener* browserlistener);

        /**
        * Called to save the brower window as a tga file.
        * @param filename Tga file to save.
        */
        void SaveTga(const std::string& filename);

        void UpdateThis(const unsigned char* pixels);

        HWND GetHwnd() {return m_hWnd;}

    private:
        /**
        * Constructor.
        * @return Browser.
        */
        Browser();

        /**
        * Creates the win32 window.
        */
        void CreateWin32Window();

        /**
        * Initializes Ogre.
        */
        void OgreInit();

        /**
        * Shows the win32 window.
        */
        void ShowWindow();

        /**
        * Does the win32 message queue loop.
        */
        void MessageLoop();

        /**
        * Creates the uOgreBrowser material.
        */
        void CreateMaterial();

        /**
        * Updates the uOgreBrowser material.
        */
        void UpdateMaterial();

        /**
        * WindowProc that processes the messages from the message queue.
        * @param hWnd Windows handle.
        * @param msg Specifies the Windows message to be processed. 
        * @param wParam Specifies additional message-dependent information. 
        * @param lParam Specifies additional message-dependent information. 
        * @return Depends on the message sent.
        */
        static LRESULT CALLBACK WindowProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

        static Browser* sm_pInstance;     ///< The single instance.

        HWND m_hWnd;  ///< Windows handle.
        EmbeddedBrowserObserver* m_embeddedBrowserObvserver; ///< Communicates with LLMozLib.
        std::vector<IFrameListener*> m_frameListeners;   ///< List of objects that want to be notified of frame events.
    };
}
