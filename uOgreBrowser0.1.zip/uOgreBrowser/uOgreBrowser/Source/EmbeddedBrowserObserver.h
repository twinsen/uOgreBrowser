#include <llmozlib.h>
#include <windows.h>
#include <vector>
#include "IBrowserListener.h"

namespace uOgreBrowser
{

class EmbeddedBrowserObserver : public LLEmbeddedBrowserWindowObserver
{
public:

    /**
    * Constructor.
    * @param hWnd Window handle.
    * @return EmbeddedBrowserObserver.
    */
    EmbeddedBrowserObserver(HWND hWnd);

    /**
    * Called to get new browser data each frame.
    */
    unsigned char* EmbeddedBrowserObserver::GrabNewBrowserData();

    /**
    * Called to save the brower window as a tga file.
    * @param filename Tga file to save.
    */
    void SaveTga(const std::string& filename);

    void MouseButtonLeftDown(int x, int y);
    void MouseButtonLeftUp(int x, int y);
    void MouseMove(int x, int y);
    void KeyDown(unsigned char key);

    ///LLEmbeddedBrowserWindowObserver events
    void onPageChanged(const EventType& eventIn);
    void onNavigateBegin(const EventType& eventIn) {};
    void onNavigateComplete(const EventType& eventIn);
    void onUpdateProgress(const EventType& eventIn) {};
    void onStatusTextChange(const EventType& eventIn) {};
    void onLocationChange(const EventType& eventIn) {};
    void onClickLinkHref(const EventType& eventIn);

void AddBrowserListener(IBrowserListener* browserlistener);

private:
    /**
    * Initializes the LLMozLib Browser window and navigates to the home page.
    */
    void Initialize();
public:
    int m_browserWindowId;  ///< LLMozLib Browser window Id.
    bool m_needsUpdate;     ///< Flag to indicate if browser texture needs an update.
    HWND m_hWnd;            ///< Window handle.

        std::vector<IBrowserListener*> m_browserListeners;   ///< List of objects that want to be notified of browser events.

};

}

