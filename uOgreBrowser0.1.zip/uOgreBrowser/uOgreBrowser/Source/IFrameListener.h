#pragma once

#include <windows.h>

namespace uOgreBrowser
{
    /**
    * Implement this interface in any class where you want to listen for frame events.
    */
    class IFrameListener
    {
    public:
        /**
        * Called before a frame is rendered.
        */
        virtual void BeginFrame() = 0;
        /**
        * Called after a frame is rendered.
        */
        virtual void EndFrame() = 0;
    };
}
