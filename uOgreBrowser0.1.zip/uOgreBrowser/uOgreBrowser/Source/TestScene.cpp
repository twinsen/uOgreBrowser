#include "TestScene.h"
#include <OgreFontManager.h> 
#include "Utilities\Application.h"
#include "Materials\OgreColorFactory.h"
#include "Browser.h"

using namespace Ogre;

namespace uOgreBrowser
{
void CreateColorTexture(std::string name, int red, int green, int blue, int alpha)
{
	// Create the texture
	TexturePtr texture = TextureManager::getSingleton().createManual(
		name.c_str(), // name
		ResourceGroupManager::DEFAULT_RESOURCE_GROUP_NAME,
		TEX_TYPE_2D,      // type
		256, 256,         // width & height
		0,                // number of mipmaps
		PF_BYTE_BGRA,     // pixel format
		TU_DEFAULT);      // usage; should be TU_DYNAMIC_WRITE_ONLY_DISCARDABLE for
	// textures updated very often (e.g. each frame)

	// Get the pixel buffer
	HardwarePixelBufferSharedPtr pixelBuffer = texture->getBuffer();

	// Lock the pixel buffer and get a pixel box
	pixelBuffer->lock(HardwareBuffer::HBL_NORMAL); // for best performance use HBL_DISCARD!
	const PixelBox& pixelBox = pixelBuffer->getCurrentLock();

	uint8* pDest = static_cast<uint8*>(pixelBox.data);

	// Fill in some pixel data. This will give a semi-transparent blue,
	// but this is of course dependent on the chosen pixel format.
	for (size_t j = 0; j < 256; j++)
		for(size_t i = 0; i < 256; i++)
		{
			*pDest++ = blue;  // B
			*pDest++ = green; // G
			*pDest++ = red;   // R
			*pDest++ = alpha; // A
		}

		// Unlock the pixel buffer
		pixelBuffer->unlock();

}

void CreateColorMaterial(std::string name, int red, int green, int blue, int alpha)
{
	if (Ogre::MaterialManager::getSingletonPtr()->resourceExists(name))
	{
		return;
	}

	std::string textureName = name+"Texture";
	CreateColorTexture(textureName, red, green,  blue, alpha);

	// Create a material using the texture
	MaterialPtr material = MaterialManager::getSingleton().create(
		name, // name
		ResourceGroupManager::DEFAULT_RESOURCE_GROUP_NAME);

	material->createTechnique()->createPass()->createTextureUnitState(textureName);
}

TestScene::TestScene(Browser* browser) : m_browser(browser)
    {
        // Setup paths.
        Root* root = Root::getSingletonPtr();
        std::string startupPath = Utilities::Application::GetStartupPath();
        std::string mediaPath = startupPath+"\\..\\media";
        root->addResourceLocation(mediaPath,"FileSystem");
        Ogre::ResourceGroupManager::getSingleton().initialiseAllResourceGroups();

CreateColorTexture("RedTexture",255,0,0,255);
CreateColorTexture("GreenTexture",0,255,0,255);
CreateColorTexture("BlueTexture",0,0,255,255);
CreateColorMaterial("BlueMaterial",0,0,255,255);

        CreateRobot();
//        CreateOverlay();
        CreateBackground();
        CreateTextOverlay();


    }

    void TestScene::CreateRobot()
    {
        // Create a robot mesh.
        Root* root = Root::getSingletonPtr();
        SceneManager* sceneManager = root->getSceneManager("generic");

        m_robotEntity = sceneManager->createEntity("Robot","robot.mesh");
        SceneNode* sceneNode = sceneManager->getRootSceneNode()->createChildSceneNode("RobotNode");
        sceneNode->attachObject(m_robotEntity);
    }

    void TestScene::CreateOverlay()
    {
        Materials::OgreColorFactory::GetInstance()->CreateColoredMaterial("BlueMaterial",0,0,255);

        OverlayManager& overlayManager = OverlayManager::getSingleton();
        OverlayContainer* panel = static_cast<OverlayContainer*>(
            overlayManager.createOverlayElement("Panel", "PanelName"));
        panel->setMetricsMode(Ogre::GMM_PIXELS);
//        panel->setPosition(10, 10);
//        panel->setDimensions(350, 500);
        panel->setPosition(0, 0);
        panel->setDimensions(800, 600);
        //        panel->setMaterialName("UOgreBrowserMaterial"); // Optional background material
//        panel->setMaterialName("BlueMaterial"); // Optional background material
        panel->setMaterialName("uOgreBrowserMaterial"); // Optional background material
        
        Overlay* overlay = overlayManager.create("OverlayName");
        overlay->add2D(panel);
        overlay->show();

    }

    void TestScene::CreateBackground()
    {
        Root* root = Root::getSingletonPtr();
        SceneManager* sceneManager = root->getSceneManager("generic");

//        Materials::OgreColorFactory::GetInstance()->CreateColoredMaterial("BaseWhiteNoLighting",255,255,255);
        Materials::OgreColorFactory::GetInstance()->CreateColoredMaterial("GreenMaterial",0,255,0);

        std::string materialName = "GreenMaterial";
materialName = "uOgreBrowserMaterial";
        MaterialPtr material = MaterialManager::getSingleton().getByName(materialName);
        material->setDepthWriteEnabled(false);

        // Create background rectangle covering the whole screen
        Rectangle2D* rect = new Rectangle2D(true);

        //left,top,right,bottom. Needs to be 1.001 so DX9 doesn't lose pixels. OpenGL works fine either way.
        rect->setCorners(-1.001, 1.001, 1, -1);
        rect->setMaterial(materialName);

        // Render the background before everything else
        rect->setRenderQueueGroup(RENDER_QUEUE_BACKGROUND);

        // Hacky, but we need to set the bounding box to something big
        // NOTE: If you are using Eihort, please see the note below on setting the bounding box
        rect->setBoundingBox(AxisAlignedBox(-100000.0*Vector3::UNIT_SCALE, 100000.0*Vector3::UNIT_SCALE));

        // Attach background to the scene
        SceneNode* node = sceneManager->getRootSceneNode()->createChildSceneNode("Background");

        node->attachObject(rect);
    }

    void TestScene::CreateTextOverlay()
    {
        // get the font manager
        FontManager &fontMgr = FontManager::getSingleton();
        // create a font resource
        ResourcePtr font = fontMgr.create("MyFont","General");
        // set as truetype
        font->setParameter("type","truetype");
        // set the .ttf file name
        font->setParameter("source","arial.ttf");
        // set the size
        font->setParameter("size","16");
        // set the dpi
        font->setParameter("resolution","96");
        // load the ttf
        font->load();

        // get the overlay manager
        OverlayManager& overlayMgr = OverlayManager::getSingleton();

        // Create a panel
        Ogre::OverlayContainer* panel = static_cast<OverlayContainer*>(
            overlayMgr.createOverlayElement("Panel", "TextPanelName"));
        panel->setMetricsMode(Ogre::GMM_PIXELS);
        panel->setPosition(10, 10);
        panel->setDimensions(100, 100);

        // Create a text area
        m_textArea = static_cast<TextAreaOverlayElement*>(
            overlayMgr.createOverlayElement("TextArea", "TextAreaName"));
        m_textArea->setMetricsMode(Ogre::GMM_PIXELS);
        m_textArea->setPosition(0, 0);
        m_textArea->setDimensions(100, 100);
        m_textArea->setCharHeight(16);
        // set the font name to the font resource that you just created.
        m_textArea->setFontName("MyFont");
        m_textArea->setColour(ColourValue(0,0,0,1));
        // say something
        m_textArea->setCaption("Hello, World!"); 

        // Create an overlay, and add the panel
        Ogre::Overlay* overlay = overlayMgr.create("TextOverlayName");
        overlay->add2D(panel);

        // Add the text area to the panel
        panel->addChild(m_textArea);

        // Show the overlay
        overlay->show();
    }

    void TestScene::BeginFrame()
    {
    }

    void TestScene::ChangeRobotTexture(std::string textureName)
    {
        MaterialPtr material = MaterialManager::getSingleton().getByName("Examples/Robot");
        material->getTechnique(0)->getPass(0)->removeAllTextureUnitStates();
        material->getTechnique(0)->getPass(0)->createTextureUnitState(textureName);
    }

    void TestScene::ToggleRobotVisibility()
    {
        m_robotEntity->setVisible(!m_robotEntity->getVisible());
    }

    void TestScene::ChangeText(std::string text)
    {
        m_textArea->setCaption(text);
    }

    void TestScene::ProcessEvent(std::string event)
    {
        if (event == "SaveUBrowserTexture")
        {
            m_browser->SaveTga("uOgreBrowser.tga");
        }
        else if (event.find("ChangeRobotTexture")!=-1)
        {
            if (event.find("Red")!=-1)
            {
                ChangeRobotTexture("RedTexture");
            }
            else if (event.find("Green")!=-1)
            {
                ChangeRobotTexture("GreenTexture");
            }
            else if (event.find("Blue")!=-1)
            {
                ChangeRobotTexture("BlueTexture");
            }
            else if (event.find("Original")!=-1)
            {
                ChangeRobotTexture("r2skin.jpg");
            }
        }
        else if (event.find("ToggleRobotVisibility")!=-1)
        {
            ToggleRobotVisibility();
        }
        else if (event.find("ChangeText")!=-1)
        {
            std::string replaceText = event.substr(event.find("ChangeText=")+11);

            //replace + with " "
            while (replaceText.find("+")!=-1)
            {
                std::string left = replaceText.substr(0,replaceText.find("+"));
                std::string right = replaceText.substr(replaceText.find("+")+1);
                replaceText = left+" "+right;
            }

            //replace hex escape chars
            //%HEX convert to dec and then store as char
            //%=%25, 37
            //@=%40, 64
            std::string accumHexConverted = "";
            while (replaceText.find("%")!=-1)
            {
                std::string left = replaceText.substr(0,replaceText.find("%"));
                std::string hexString = replaceText.substr(replaceText.find("%")+1,2);
                std::string right = replaceText.substr(replaceText.find("%")+3);

                int num = 0;
                std::stringstream converter;
                converter << std::hex << "0x" << hexString;
                converter >> num;

                accumHexConverted = accumHexConverted+left+(char)num;
                replaceText = right;
            }
            accumHexConverted = accumHexConverted+replaceText;
            replaceText = accumHexConverted;

            ChangeText(replaceText);
        }
    }

    void TestScene::OnClickLinkHref(std::string value)
    {
        std::stringstream buffer;
        buffer << "Event: clicked on link to " << value << std::endl;
        OutputDebugString(buffer.str().c_str());
        SetWindowText(m_browser->GetHwnd(),value.c_str());

        std::cout << "Event: clicked on link to " << value << std::endl;
        ProcessEvent(value);
    }

    void TestScene::OnNavigateComplete(std::string eventUri)
    {
        std::stringstream buffer;
        buffer << "Event: end navigation to " << eventUri << std::endl;
        OutputDebugString(buffer.str().c_str());
        SetWindowText(m_browser->GetHwnd(),eventUri.c_str());

        std::cout << "Event: end navigation to " << eventUri << std::endl;
        ProcessEvent(eventUri);
    }
}
