#include "Browser.h"
#include "TestScene.h"

using namespace uOgreBrowser;

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR lpCmdLine, int nCmdShow)
{
    Browser* browser = Browser::GetInstance();
    TestScene* testScene = new TestScene(browser);
    browser->AddFrameListener(testScene);
    browser->AddBrowserListener(testScene);
    browser->Run();
	return 0;
}

/*
#include <windows.h>
#include "EmbeddedBrowserObserver.h"

//#region proc
static LRESULT CALLBACK WindowProc( HWND   hWnd, 
                                   UINT   msg, 
                                   WPARAM wParam, 
                                   LPARAM lParam )
{
    switch( msg )
    {
    case WM_KEYDOWN:
        {
            switch( wParam )
            {

            case VK_ESCAPE:
                PostQuitMessage(0);
                break;
            }
        }
        break;

    case WM_CLOSE:
    case WM_DESTROY:
        {
            PostQuitMessage(0);
        }
        break;

    default:
        {
            return DefWindowProc( hWnd, msg, wParam, lParam );
        }
        break;
    }

    return 0;
}
//#endregion

int APIENTRY WinMain(HINSTANCE hInstance1, HINSTANCE hPrevInstance, LPTSTR lpCmdLine, int nCmdShow)
{

    //#region win
    WNDCLASSEX winClass;
    MSG        uMsg;
    HWND hWnd;

    memset(&uMsg,0,sizeof(uMsg));

    HINSTANCE hInstance = GetModuleHandle(NULL);

    winClass.lpszClassName = "MY_WINDOWS_CLASS";
    winClass.cbSize        = sizeof(WNDCLASSEX);
    winClass.style         = CS_HREDRAW | CS_VREDRAW;
    winClass.lpfnWndProc   = WindowProc;
    winClass.hInstance     = hInstance;
    winClass.hIcon	       = LoadIcon(hInstance, (LPCTSTR)IDI_APPLICATION);
    winClass.hIconSm	   = LoadIcon(hInstance, (LPCTSTR)IDI_APPLICATION);
    winClass.hCursor       = LoadCursor(NULL, IDC_ARROW);
    winClass.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
    winClass.lpszMenuName  = NULL;
    winClass.cbClsExtra    = 0;
    winClass.cbWndExtra    = 0;

    RegisterClassEx(&winClass);

    hWnd = CreateWindowEx( NULL, "MY_WINDOWS_CLASS", 
        "SomeOtherName",
        WS_OVERLAPPEDWINDOW | WS_VISIBLE,
        0, 0, 900-92, 700-73, NULL, NULL, hInstance, NULL );
    ShowWindow( hWnd, 1 );
    UpdateWindow( hWnd );
    //#endregion

    EmbeddedBrowserObserver* embeddedBrowserObvserver = new EmbeddedBrowserObserver(hWnd);


    while( uMsg.message != WM_QUIT )
    {
        if( PeekMessage( &uMsg, NULL, 0, 0, PM_REMOVE ) )
        { 
            TranslateMessage( &uMsg );
            DispatchMessage( &uMsg );
        }
        else
        {
            embeddedBrowserObvserver->GrabNewBrowserData();
        }
    }

    return 0;
}
*/