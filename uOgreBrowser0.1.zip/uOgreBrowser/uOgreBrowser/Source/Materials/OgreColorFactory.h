#include <string>

namespace uOgreBrowser
{
    namespace Materials
    {
        /**
        * Creates color materials and textures.
        */
        class OgreColorFactory 
        {
        public:
            /**
            * Returns the single instance of the OgreColorFactory.
            * @return OgreColorFactory.
            */
            static OgreColorFactory* GetInstance();

            /**
            * Creates some default color materials using Color.Name syntax and values using 
            * .Net conventions.
            * Current colors:
            * Color.LightGreen, Color.Green, Color.DarkGreen, Color.Red, Color.DarkRed, 
            * Color.Blue, Color.White, Color.Gray
            */
            void CreateDefaultColors();

            /**
            * Creates a colored texture just so we don't have to use a filename for 
            * testing with textures.
            * @param textureName The name used by Ogre to reference the texture.
            * @param R Amount of red (0-255).
            * @param G Amount of green (0-255).
            * @param B Amount of blue (0-255).
            */
            void CreateColoredTexture(std::string textureName, int R, int G, int B);

            /**
            * Creates a colored material so we don't need a material file for 
            * testing with materials.
            * @param materialName The name used by Ogre to reference the material.
            * @param R Amount of red (0-255).
            * @param G Amount of green (0-255).
            * @param B Amount of blue (0-255).
            */
            void CreateColoredMaterial(std::string materialName, int R, int G, int B);

        private:
            /**
            * Constructor.
            * @return OgreColorFactory.
            */
            OgreColorFactory();

            OgreColorFactory(const OgreColorFactory&);  ///< not implemented
            OgreColorFactory& operator= (const OgreColorFactory&); ///< not implemented

            static OgreColorFactory* sm_pInstance;   ///< Singleton instance.
        };
    }
}
