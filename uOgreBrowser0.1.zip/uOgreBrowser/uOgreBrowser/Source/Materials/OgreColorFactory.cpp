#include "OgreColorFactory.h"
#include <Ogre.h>

namespace uOgreBrowser
{
    namespace Materials
    {
        OgreColorFactory* OgreColorFactory::sm_pInstance = NULL;// initialize pointer

        OgreColorFactory* OgreColorFactory::GetInstance() 
        {
            if (sm_pInstance == NULL)
            {  
                sm_pInstance = new OgreColorFactory();
            }
            return sm_pInstance;
        }

        OgreColorFactory::OgreColorFactory()
        {
        }

        void OgreColorFactory::CreateDefaultColors()
        {
            //Just create some default ones here.
            //Color.Name syntax and values are taken from .Net convention.
            CreateColoredMaterial("Color.LightGreen",144,238,144);
            CreateColoredMaterial("Color.Green",0,128,0);
            CreateColoredMaterial("Color.DarkGreen",0,100,0);
            CreateColoredMaterial("Color.Red",255,0,0);
            CreateColoredMaterial("Color.DarkRed",139,0,0);
            CreateColoredMaterial("Color.Blue",0,0,255);
            CreateColoredMaterial("Color.White",255,255,255);
            CreateColoredMaterial("Color.Gray",128,128,128);
        }

        void OgreColorFactory::CreateColoredTexture(std::string textureName, int R, int G, int B)
        {
            if (!Ogre::TextureManager::getSingletonPtr()->resourceExists(textureName))
            {
                Ogre::TexturePtr texture = Ogre::TextureManager::getSingleton().createManual(
                    textureName.c_str(), // name
                    Ogre::ResourceGroupManager::DEFAULT_RESOURCE_GROUP_NAME,
                    Ogre::TEX_TYPE_2D,      // type
                    256, 256,         // width & height
                    0,                // number of mipmaps
                    Ogre::PF_BYTE_BGRA,     // pixel format
                    Ogre::TU_DEFAULT);      // usage; should be TU_DYNAMIC_WRITE_ONLY_DISCARDABLE for
                // textures updated very often (e.g. each frame)
                // Get the pixel buffer
                Ogre::HardwarePixelBufferSharedPtr pixelBuffer = texture->getBuffer();

                // Lock the pixel buffer and get a pixel box
                pixelBuffer->lock(Ogre::HardwareBuffer::HBL_NORMAL); // for best performance use HBL_DISCARD!
                const Ogre::PixelBox& pixelBox = pixelBuffer->getCurrentLock();

                Ogre::uint8* pDest = static_cast<Ogre::uint8*>(pixelBox.data);

                // Fill in some pixel data.
                for (size_t j = 0; j < 256; j++)
                {
                    for(size_t i = 0; i < 256; i++)
                    {
                        *pDest++ = B; // B
                        *pDest++ = G; // G
                        *pDest++ = R; // R
                        *pDest++ = 255; // A
                    }
                }

                // Unlock the pixel buffer
                pixelBuffer->unlock();
            }
        }

        void OgreColorFactory::CreateColoredMaterial(std::string materialName, int R, int G, int B)
        {
            if (!Ogre::MaterialManager::getSingletonPtr()->resourceExists(materialName))
            {
                CreateColoredTexture(materialName+"Texture", R,G,B);
                //Create the material
                Ogre::MaterialPtr material = Ogre::MaterialManager::getSingleton().create(
                    materialName, Ogre::ResourceGroupManager::DEFAULT_RESOURCE_GROUP_NAME);
                material->getTechnique(0)->getPass(0)->createTextureUnitState(materialName+"Texture");
            }
        }
    }
}
