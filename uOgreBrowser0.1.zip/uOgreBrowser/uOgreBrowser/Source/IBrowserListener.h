#pragma once

#include <windows.h>

namespace uOgreBrowser
{
    /**
    * Implement this interface in any class where you want to listen for browser events.
    */
    class IBrowserListener
    {
    public:
        /**
        * Called after navigation to a webpage is complete.
        */
        virtual void OnNavigateComplete(std::string eventUri) = 0;

        /**
        * Called when clicked a webpage link.
        */
        virtual void OnClickLinkHref(std::string value) = 0;
    };
}
