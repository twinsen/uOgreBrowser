#pragma once
#include <string>

namespace uOgreBrowser
{
    namespace Utilities
    {
        /**
        * Class intended to mimick some of .Net's System.Windows.Forms.Application functionality 
        * without being managed.
        */
        class Application 
        {
        public:
            /**
            * Gets the path for the executable file that started the application, 
            * including the executable name.  
            * @return Path for the executable including filename.
            */
            static std::string GetExecutablePath();

            /**
            * Gets the path for the executable file that started the application, 
            * not including the executable name.   
            * @return Path for the executable without filename.
            */
            static std::string GetStartupPath();
        };
    }
}
