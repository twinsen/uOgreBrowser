#include "Application.h"
#include <windows.h>
#include "..\IO\Path.h"

namespace uOgreBrowser
{
    namespace Utilities
    {
        std::string Application::GetExecutablePath()
        {
            char buffer[MAX_PATH];
            GetModuleFileName(NULL, buffer, MAX_PATH);
            std::string path = buffer;
            return path;
        }

        std::string Application::GetStartupPath()
        {
            return uOgreBrowser::IO::Path::GetDirectoryName(GetExecutablePath());
        }
    }
}
