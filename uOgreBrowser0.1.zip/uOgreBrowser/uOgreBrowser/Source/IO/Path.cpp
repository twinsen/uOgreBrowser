#include "Path.h"
#include <windows.h>
#include <shlwapi.h>

namespace uOgreBrowser
{
    namespace IO
    {
        std::string Path::GetDirectoryName(std::string fileName)
        {
            std::string path = "";
            char buffer[MAX_PATH];
            strcpy(buffer,fileName.c_str());
            PathRemoveFileSpec(buffer);
            path = buffer;
            return path;
        }
    }
}
