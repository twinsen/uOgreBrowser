#include <string>

namespace uOgreBrowser
{
    namespace IO
    {
        /**
        * Class intended to mimick some of .Net's System.IO.Path functionality without 
        * being managed.
        */
        class Path 
        {
        public:
            /**
            * Returns the directory information for the specified path string.  
            * @param fileName The path of a file or directory.
            * @return String containing directory information for path.
            */
            static std::string GetDirectoryName(std::string fileName);
        };
    }
}
